import 'dart:convert';
//import 'dart:html';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:bubble/bubble.dart';
import 'package:draggable_scrollbar/draggable_scrollbar.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:typed_data';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<ChatScreen> {
//defining some properties and variables
//we need state key for animated ist before

  ScrollController _scrollController = ScrollController();

  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  final List<dynamic> _data = [];
  //in flask app we define the rout for our query i.e., / bot
  // ignore: constant_identifier_names
  static const String BOT_URL =
      "https://chatbot-research-backend.herokuapp.com/";
  TextEditingController queryController = TextEditingController();

  ImagePicker _picker = ImagePicker();
  File? _image;

  getFromGallery() async {
    await Permission.photos.request();

    var permissionStatus = await Permission.photos.status;
    print(permissionStatus);

    if (permissionStatus.isGranted) {
      // XFile? pickedFile =
      // await imagePicker.pickImage(source: ImageSource.gallery);
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);

      if (image != null) {
        setState(() {
          _image = File(image.path);
          insertImagetoChat(_image);
          fishDetectResponse(image.path);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // appBar: AppBar(
      //   backgroundColor: Color.fromARGB(0, 255, 255, 255),
      //   centerTitle: true,
      //   title: const Text(
      //     "Chat Bot",
      //     style: TextStyle(color: Color.fromARGB(255, 0, 0, 0)),
      //   ),
      // ),
      body: Stack(
        children: <Widget>[
          Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                    fit: BoxFit.cover,
                    alignment: Alignment.bottomCenter,
                    image: AssetImage("./assets/images/tropicalfish.jpg"))),
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 60,
            ),
            child: Padding(
              padding: EdgeInsets.only(bottom: 70),
              child: AnimatedList(
                key: _listKey,
                initialItemCount: _data.length,
                itemBuilder: (BuildContext context, int index,
                    Animation<double> animation) {
                  return buildItem(_data[index], animation, index);
                },
              ),
            ),
          ),

          //text field icon field

          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              padding: const EdgeInsets.only(left: 10, bottom: 10, top: 10),
              height: 60,
              //width: 300,
              alignment: Alignment.bottomCenter,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: const Color.fromARGB(255, 227, 227, 227),
              ),
              //color: Color.fromARGB(255, 122, 69, 69),
              child: Row(
                children: <Widget>[
                  FloatingActionButton(
                    onPressed: () {
                      getFromGallery();
                    },
                    child: const Icon(
                      Icons.add_a_photo,
                      color: Color.fromARGB(249, 255, 255, 255),
                      size: 20,
                    ),
                    backgroundColor: const Color.fromARGB(250, 1, 53, 148),
                    elevation: 0,
                  ),
                  Expanded(
                    child: TextField(
                      decoration: const InputDecoration(
                          hintText: "Write message...",
                          hintStyle: TextStyle(color: Colors.black54),
                          border: InputBorder.none),
                      controller: queryController,
                    ),
                  ),
                  const SizedBox(
                    width: 15,
                  ),
                  FloatingActionButton(
                    onPressed: () {
                      getResponse();
                    },
                    child: const Icon(
                      Icons.send_sharp,
                      color: Color.fromARGB(249, 255, 255, 255),
                      size: 20,
                    ),
                    backgroundColor: const Color.fromARGB(250, 1, 53, 148),
                    elevation: 0,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void fishDetectResponse(image) async {
    var client = getClient();
    Map<String, String> headers = {'Content-Type': 'application/json'};

    final bytes = await File(image).readAsBytes();
    String base64string = base64.encode(bytes);
    final body = jsonEncode({"img": base64string});
    try {
      var res = await client.post(
          Uri.parse('https://fish-detection-api.herokuapp.com/uploadfile'),
          headers: headers,
          body: body);
      print(body);
      print("=======================.....=====");
      print(jsonDecode(res.body)[0]['result'][0]['description']);
      String splitDes = jsonDecode(res.body)[0]['result'][0]['description'];
      var persantage = double.parse(splitDes.split(' ')[9]);

      if (persantage < 90) {
        insertSingleItem(
            "We think this image it not related to our fish types <bot>");
      } else {
        insertSingleItem(
            jsonDecode(res.body)[0]['result'][0]['description'] + "<bot>");
      }
    } catch (e) {}
  }

  void getResponse() async {
    if (queryController.text.isNotEmpty) {
      insertSingleItem(queryController.text);

      var client = getClient();
      Map<String, String> headers = {'Content-Type': 'application/json'};

      final msg = jsonEncode({"text": queryController.text});
      queryController.clear();
      try {
        var response = await client.post(
          Uri.parse(BOT_URL + 'chat'),
          headers: headers,
          body: msg,
        );

        print("=======================.....=====");
        print(jsonDecode(response.body)[0]['result']);
        print("==========================.....==");

        List<dynamic> data = jsonDecode(response.body)[0]['result'];

        if (data.length > 1) {
          showDetailDialog(data);
          //insertSingleItem("click here <bot>");
        } else {
          List<dynamic> data = jsonDecode(response.body);
          insertSingleItem(data[0]['result'][0]['message'] + "<bot>");
        }
      } finally {
        client.close();
        queryController.clear();
      }
    }
  }

  showDetailDialog(data) {
    DraggableScrollbar.rrect(
      controller: _scrollController,
      child: ListView.builder(
        controller: _scrollController,
        itemCount: 1000,
        itemExtent: 100.0,
        itemBuilder: (context, index) {
          return Container(
            padding: EdgeInsets.all(8.0),
            height: 200,
            child: Material(
              elevation: 4.0,
              borderRadius: BorderRadius.circular(4.0),
              color: Colors.green[index % 9 * 100],
              child: Center(
                child: Text(index.toString()),
              ),
            ),
          );
        },
      ),
    );
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              contentPadding: EdgeInsets.only(left: 25, right: 25),
              title: Center(child: Text("Details")),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0))),
              content: Container(
                height: 600,
                width: 400,
                child: SingleChildScrollView(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: modelDiseaseDetail(data)),
                ),
              ));
        });
  }

  List<Widget> modelDiseaseDetail(data) {
    List<Widget> wl = [SizedBox(height: 20)];
    print(data);
    // if (data) {}
    for (var item in data) {
      wl.add(Text(
        "🐠 " + item['diseaseName'],
        style: TextStyle(fontSize: 18),
      ));
      item['symptoms'].length > 0
          ? wl.add(const SizedBox(
              height: 20,
              width: 40,
            ))
          : null;

      for (var i = 0; i < item['symptoms'].length; i++) {
        wl.add(SizedBox(
          width: 40,
        ));
        wl.add(Padding(
            padding: EdgeInsets.only(left: 6),
            child: Text(
              "🐟" + item['symptoms'][i],
            )));
      }
      wl.add(SizedBox(height: 20));
    }
    return wl;
  }

  //inserting single item
  void insertSingleItem(String message) {
    _data.add(message);
    _listKey.currentState?.insertItem(_data.length - 1);
  }

  void insertImagetoChat(dynamic item) {
    _data.add(item);
    _listKey.currentState?.insertItem(_data.length - 1);
  }

  //get client
  http.Client getClient() {
    return http.Client();
  }
}

Widget _buildRow(String imageAsset, String name, double score) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20.0),
    child: Column(
      children: <Widget>[
        SizedBox(height: 12),
        // Container(height: 2, color: Colors.redAccent),
        SizedBox(height: 12),
        Row(
          children: <Widget>[
            CircleAvatar(backgroundImage: AssetImage(imageAsset)),
            SizedBox(width: 12),
            Text(name),
            Spacer(),
            Container(
              decoration: BoxDecoration(
                  //color: Colors.yellow[900],
                  borderRadius: BorderRadius.circular(20)),
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 20),
              child: Text('$score'),
            ),
          ],
        ),
      ],
    ),
  );
}

//build item widget which will take context, animation and index as prameter
Widget buildItem(dynamic item, Animation<double> animation, int index) {
  bool mine = true;
  if (!(item.runtimeType == String)) {
    return SizeTransition(
        sizeFactor: animation,
        child: Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Container(
            height: 250.0,
            alignment: Alignment.topRight,
            child: Bubble(
              child: Image.file(
                item,
                fit: BoxFit.cover,
              ),
              color: const Color.fromARGB(255, 139, 228, 255),
              padding: const BubbleEdges.all(10),
            ),
          ),
        ));
  } else {
    mine = item.endsWith("<bot>");
    return SizeTransition(
      sizeFactor: animation,
      child: Padding(
        padding: const EdgeInsets.only(top: 10, right: 10, left: 10),
        child: Container(
          alignment: mine ? Alignment.topLeft : Alignment.topRight,
          child: Bubble(
            child: Text(
              item.replaceAll("<bot>", ""),
              style: TextStyle(
                  color: mine ? Colors.white : Color.fromARGB(255, 0, 0, 0)),
            ),
            color: mine
                ? Color.fromARGB(255, 0, 145, 248)
                : Color.fromARGB(255, 0, 183, 255),
            padding: const BubbleEdges.all(10),
          ),
        ),
      ),
    );
  }
}
