class User{
  String? name;
  String? email;
  String? password;

  User({this.name,this.email,this.password});

  factory User.fromMap(Map<String,dynamic> map){
    return User(
      name: map['name'] != null ? map['name'] as String: null,
      email: map['email'] != null ? map['email'] as String: null,
      password: map['password'] != null ? map['password'] as String: null,
    );
  }
}