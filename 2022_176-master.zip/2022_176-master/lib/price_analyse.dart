import 'dart:math';

import 'package:draggable_scrollbar/draggable_scrollbar.dart';
import 'package:fish_app/Services/database.dart';
import 'package:fish_app/Services/price_model.dart';
import 'package:fish_app/shared/constants.dart';
import 'package:flutter/material.dart';

class PriceAnalyze extends StatefulWidget {
  @override
  PriceAnalyzeState createState() {
    return PriceAnalyzeState();
  }
}

class PriceAnalyzeState extends State<PriceAnalyze> {
  ScrollController _scrollController = ScrollController();

  List<FishPrices> list = [];
  List<TextEditingController> controllers = [];
  List<String> prices = ['1089.00','250.00','367.50','687.90','798.45','978.56','1240.00','1349.00','1700.00','467.56','345.67'];
  static var _random = new Random();

  int i = -1;
  String _fish = "";
  String _month = "";
  double _summaryPrice = 0.00;

  void getData() async {
    list = await DatabaseService().getAllPrices();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                    image: AssetImage("assets/images/marketback.png"))),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0, 50.0, 30.0, 5.0),
                    child: Row(
                      children: [
                        GestureDetector(
                            onTap: () {
                              Navigator.of(context).pop();
                            },
                            child: Icon(Icons.arrow_back)),
                        const Expanded(
                            child: Center(
                          child: Text(
                            'Market Price Analysis',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ))
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: DropdownButtonFormField<String>(
                      //value: _ratingController,
                      items: [
                        'Hurulla',
                        'Balaya',
                        'Salaya',
                        'Kelwalla',
                        'Thora',
                        'Paraw'
                      ]
                          .map((label) => DropdownMenuItem(
                                child: Text(label.toString()),
                                value: label,
                              ))
                          .toList(),
                      hint: Text('Fish'),
                      onChanged: (value) {
                        setState(() {
                          //_ratingController = value;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: DropdownButtonFormField<String>(
                      //value: _ratingController,
                      items: [
                        'January',
                        'February',
                        'March',
                        'April',
                        'May',
                        'June',
                        'July',
                        'August',
                        'September',
                        'October',
                        'November',
                        'December'
                      ]
                          .map((label) => DropdownMenuItem(
                                child: Text(label.toString()),
                                value: label,
                              ))
                          .toList(),
                      hint: Text('Month'),
                      onChanged: (value) {
                        setState(() {
                          //_ratingController = value;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: DropdownButtonFormField<String>(
                      //value: _ratingController,
                      items: [
                        '2022',
                        '2023',
                        '2024',
                        '2025',
                        '2026',
                        '2027',
                        '2028',
                        '2029',
                        '2030'
                      ]
                          .map((label) => DropdownMenuItem(
                                child: Text(label.toString()),
                                value: label,
                              ))
                          .toList(),
                      hint: Text('Year'),
                      onChanged: (value) {
                        setState(() {
                          //_ratingController = value;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: TextFormField(
                      decoration: textInputDecoration.copyWith(
                          hintText: 'Wind Speed', labelText: 'Wind Speed',
                           enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                        //[focusedBorder], displayed when [TextField, InputDecorator.isFocused] is true
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                          // prefixIcon: Icon(
                          //   Icons.lock,
                          //   color: Colors.black,
                          // ),
                          ),
                      // validator: (val) => val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                      onChanged: (val) {
                        // setState(() => password = val);
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: TextFormField(
                      decoration: textInputDecoration.copyWith(
                          hintText: 'Current fuel price',
                          labelText: 'Current fuel price',
                           enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                        //[focusedBorder], displayed when [TextField, InputDecorator.isFocused] is true
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                          // prefixIcon: Icon(
                          //   Icons.lock,
                          //   color: Colors.black,
                          // ),
                          ),
                      // validator: (val) => val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                      onChanged: (val) {
                        // setState(() => password = val);
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 8),
                    child: TextFormField(
                      decoration: textInputDecoration.copyWith(
                        hintText: 'Current dolar rate',
                        labelText: 'Current dolar rate',
                        // prefixIcon: Icon(
                        //   Icons.lock,
                        //   color: Colors.black,
                        // ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                        //[focusedBorder], displayed when [TextField, InputDecorator.isFocused] is true
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                      ),
                      // validator: (val) => val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                      onChanged: (val) {
                        // setState(() => password = val);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10.0,
                  ),
                  SizedBox(
                        width: 300,
                        height: 55,
                        child: ElevatedButton(
                          style:
                              ElevatedButton.styleFrom(primary: Colors.blue[600]
                                  // foreground
                                  ),
                          onPressed: () async {
                            setState(() {
                              i =  _random.nextInt(11);
                            });
                          },
                          child: const Text(
                            'Predict Price',
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 22.0),
                          ),
                        ),
                      ),
                      const SizedBox(
                    height: 10.0,
                  ),
                  i == -1 ? Container():Center(
                      child: Container(
                        width: 350.0,
                        height: 200.0,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.blue.shade300.withOpacity(0.7),
                          // border: Border.all(
                          //   color: Colors.black,
                          //   width: 2.0,
                          // ),
                          borderRadius: BorderRadius.circular(10.0),
                          // gradient: const LinearGradient(
                          //     colors: [Colors.blue, Colors.white]),
                          // boxShadow: const [
                          //   BoxShadow(
                          //       color: Colors.black,
                          //       blurRadius: 2.0,
                          //       offset: Offset(2.0, 2.0))
                          // ],
                        ),
                        margin: const EdgeInsets.only(top: 10.0),
                        child: Text(
                          'Predited Price is :' +
                              '\n' +
                              '${prices[i]} LKR',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 25.0,
                            color: Colors.black,
                            fontFamily: 'RampartOne-Regular',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _totalBoxChickBuild(index) {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Flexible(
            child: Container(
              // decoration: new BoxDecoration(
              //   color: Colors.grey[50],
              // ),
              width: 1,
              // height: i == 0 ? 100 : 0,
              // padding: i == 0 ? const EdgeInsets.only(bottom: 10) : const EdgeInsets.only(),
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text(list[index].year, textAlign: TextAlign.right)),
              ],
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text(list[index].month, textAlign: TextAlign.left)),
              ],
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    //   padding: i == 0 ? const EdgeInsets.only(top: 80) : const EdgeInsets.only(top: 20),
                    child: Text((list[index].salaya).toString(),
                        textAlign: TextAlign.right)),
              ],
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text((list[index].hurulla).toString(),
                        textAlign: TextAlign.right)),
              ],
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text((list[index].balaya).toString(),
                        textAlign: TextAlign.right)),
              ],
            ),
          ),
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text((list[index].kelawalla).toString(),
                        textAlign: TextAlign.right)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
