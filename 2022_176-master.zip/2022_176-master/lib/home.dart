import 'package:fish_app/Authenticate/login.dart';
import 'package:fish_app/Services/database.dart';
import 'package:fish_app/Services/price_model.dart';
import 'package:fish_app/ShrimpDisease.dart';
import 'package:fish_app/fish_detect.dart';
import 'package:fish_app/price_analyse.dart';
import 'package:flutter/material.dart';
import 'package:fish_app/chatbot_main_screen.dart';

//// Home function
class Home extends StatefulWidget {
  final String username;
  Home(this.username);
  @override
  HomeState createState() {
    return HomeState();
  }
}

class HomeState extends State<Home> {
  bool _inserted = false;
  // bool collector=false;

  @override
  void initState() {
    super.initState();
    DatabaseService().initDatabase();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fish App',
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        // visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Scaffold(
          body: Container(
              constraints: const BoxConstraints.expand(),
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                      "assets/images/underwater-world.png"), // setting background image
                  fit: BoxFit.cover,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    // const Text("Menu", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0)),
                    // const SizedBox(width: 300,height: 10),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Hi ${widget.username} 👋,",
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 25.0)),
                          const Text("Welcome to Fish App.",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 20.0)),
                        ],
                      ),
                    ),

                    // const Text("Detect Fish Species, Detect  from your mobile.", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0)),
                    // SizedBox(width: 300,height: 15),

                    // redirects to detection adding form
                    const SizedBox(width: 300, height: 40),
                    Card(
                      margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: const Text('🐠',
                                style: TextStyle(fontSize: 30)),
                            title: const Text("Detect Fish Species",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                )),
                            // subtitle: Text("Detect Garbage from your camera"),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FishDetection()),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    // redirects to verify detection view
                    Card(
                      margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: const Text('🦐',
                                style: TextStyle(fontSize: 30)),
                            title: const Text("Detect Shrimp Diseases",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                )),
                            // subtitle: Text("Verify Detected Garbage."),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ShrimpDisease()),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    Card(
                      margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Text(
                              '💸',
                              style: TextStyle(fontSize: 30),
                            ),
                            title: Text("Market Price Analysis",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                )),
                            // subtitle: Text("Verify Detected Garbage."),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => PriceAnalyze()),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    // ChatBot
                    Card(
                      margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Text(
                              '📱',
                              style: TextStyle(fontSize: 30),
                            ),
                            title: Text("Ornamental fish disease",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                )),
                            // subtitle: Text("Verify Detected Garbage."),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ChatbotMainScreen()),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(
                      width: 300,
                      height: 30,
                    ),

                    const SizedBox(
                      width: 300,
                      height: 30,
                    ),
                  ],
                ),
              ))),
    );
  }
}
