import 'package:flutter/material.dart';
import 'package:fish_app/chat_screen.dart';

class ChatbotMainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<ChatbotMainScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 199, 243, 250),
      // appBar: AppBar(
      //   backgroundColor: Color.fromARGB(0, 255, 255, 255),
      //   centerTitle: true,
      //   title: Text(
      //     "Chat Bot",
      //     style: TextStyle(color: Color.fromARGB(255, 0, 0, 0)),
      //   ),
      // ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Container(
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 50,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 5),
                        child: Center(
                          child: Image.asset(
                            "./assets/images/ocean.png",
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 40, top: 20),
                        child: Text(
                          "Welcome to Chatty",
                          style: TextStyle(
                              fontSize: 36,
                              //height: 3,
                              fontFamily: "FredokaOne",
                              color: Color.fromARGB(250, 0, 168, 224)),
                        ),
                      ),
                      Text(
                          "By using me\n you can identify\n Ornamental fish diseases and\n relavant treatments",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color.fromARGB(255, 160, 160, 160),
                            fontSize: 25,
                            fontFamily: "Fresca",
                          )),
                    ],
                  ),
                ),
                Container(
                    child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ChatScreen()),
                    );
                  },
                  child: Container(
                      margin: EdgeInsets.all(60),
                      padding: EdgeInsets.all(20),
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(249, 28, 146, 185),
                          borderRadius: BorderRadius.circular(30)),
                      child: Center(
                          child: Text(
                        "Get Started",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontFamily: "Poppins"),
                      ))),
                ))
              ],
            ),
          ),
        ],
      ),
    );
  }
}
