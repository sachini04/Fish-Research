import 'dart:async';

import 'package:fish_app/Services/price_model.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/user.dart';

class DatabaseService {
  static Database? db;

  Future<Database> get database async =>
      db ??= await initDatabase();

  final String priceTable = 'fish_prices';

  initDatabase() async {
    var dbPath = await getDatabasesPath();
    String path = join(dbPath, 'ravifarm.db');

    db = await openDatabase(path, version: 2,
        onCreate: (db, int version) async {
          await db.execute(
              'CREATE TABLE IF NOT EXISTS $priceTable (id INTEGER PRIMARY KEY, year TEXT, month TEXT, salaya DOUBLE, hurulla DOUBLE, balaya DOUBLE, kelawalla DOUBLE)');
       await db.execute(
              'CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY, name TEXT, email TEXT, password TEXT )');
        });

    print(db);
  }

  Future<bool> insertUser(String name,String email, String password)async {
    await initDatabase();
   int k = await db!.insert('Users', {'name':name,'email':email,'password':password});
   return k > 0;
  }

  Future<String> login(String email,String password)async{
    await initDatabase();
    String name = '';
    var result = await db!.rawQuery("""
                                Select * from Users WHERE email = '$email' AND password = '$password'
                              """);
    if(result.map((e) => User.fromMap(e)).toList().isNotEmpty){
     name = result.map((e) => User.fromMap(e)).toList().first.name!;
    }
    return name;
  }

  Future<bool> insertPrices(FishPrices fPrices) async {
    try{
      await db!.insert(priceTable, fPrices.toMap());
      // print("hii");
      return true;
    }
    catch(e){
      print(e);
      return false;
    }
  }

  Future<List<FishPrices>> getAllPrices() async {
    final List<Map<String, dynamic>> maps = await db!.query(priceTable);
    print(maps);

    // Convert the List<Map<String, dynamic> into a List<Dog>.
    return List.generate(maps.length, (i) {
      return FishPrices(
        id: maps[i]['id'],
        year: maps[i]['year'],
        month: maps[i]['month'],
        salaya: maps[i]['salaya'],
        hurulla: maps[i]['hurulla'],
        balaya: maps[i]['balaya'],
        kelawalla: maps[i]['kelawalla'],
      );
    });
  }

  Future<int?> countPriceData() async {
    int? count = Sqflite
        .firstIntValue(await db!.rawQuery('SELECT COUNT(*) FROM $priceTable'));

    return count;
  }

  Future<bool> deletePrices() async {
    await db!.execute("delete from $priceTable");

    int? count = Sqflite
        .firstIntValue(await db!.rawQuery('SELECT COUNT(*) FROM $priceTable'));
  print(count);
    if(count ==0){
      return true;
    } else{
      return false;
    }
  }
}