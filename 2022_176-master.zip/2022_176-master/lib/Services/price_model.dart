class FishPrices {
  int? id = null;
  String year;
  String month;
  double salaya;
  double hurulla;
  double balaya;
  double kelawalla;

  FishPrices({
    this.id,
    required this.year,
    required this.month,
    required this.salaya,
    required this.hurulla,
    required this.balaya,
    required this.kelawalla
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'year': year,
      'month': month,
      'salaya': salaya,
      'hurulla': hurulla,
      'balaya': balaya,
      'kelawalla': kelawalla,
    };
  }
}