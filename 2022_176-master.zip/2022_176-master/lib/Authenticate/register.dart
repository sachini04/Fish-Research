import 'package:fish_app/Services/database.dart';
import 'package:flutter/material.dart';
import 'package:fish_app/Authenticate/login.dart';
import 'package:fish_app/shared/constants.dart';
import 'package:fish_app/shared/loading.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {

  final _formKey = GlobalKey<FormState>();
  String error = '';
  bool loading = false;

  // text field state
  String name = '';
  String email = '';
  String contact = '';
  String userType = '';
  String password = '';
  String address = '';
  String city = '';

  @override
  Widget build(BuildContext context) {
    return loading ? Loading() : Scaffold(
      backgroundColor: Colors.blue.shade100,
     
      body: Stack(
        children: <Widget>[
           Container(
                  decoration: new BoxDecoration(
                      image: new DecorationImage(
                          fit: BoxFit.fitWidth,
                          alignment: Alignment.bottomCenter,
                          image: AssetImage(
                              "assets/images/fish_back.png"))),
                ),
                Container(
                  decoration: new BoxDecoration(
                      image: new DecorationImage(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.topCenter,
                          image: AssetImage(
                              "assets/images/logo2.png"))),
                ),
            Center(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(30.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Center(child: Text('Sign Up',style: TextStyle(fontSize: 42),)),
                           SizedBox(
                            height: 25.0,
                          ),
                        TextFormField(
                          decoration: textInputDecoration.copyWith(
                              hintText: 'Name',
                              prefixIcon: const Icon(
                                Icons.person,
                                color: Colors.black,
                              ),
                          ),
                          validator: (val) => val!.isEmpty ? 'Enter name' : null,
                          onChanged: (val) {
                            setState(() => name = val);
                          },
                        ),
                        SizedBox(height: 15.0,),

                        TextFormField(
                          // decoration: textInputDecoration.copyWith(hintText: 'email'),
                          decoration: textInputDecoration.copyWith(
                            hintText: 'Email',
                            prefixIcon: const Icon(
                              Icons.email_rounded,
                              color: Colors.black,
                            ),
                          ),
                          validator: (val) => val!.isEmpty ? 'Enter an email' : null,
                          onChanged: (val) {
                            setState(() => email = val);
                          },
                        ),
                        SizedBox(height: 15.0,),

                        // TextFormField(
                        //   // decoration: textInputDecoration.copyWith(hintText: 'contact number'),
                        //   decoration: textInputDecoration.copyWith(
                        //     hintText: 'Contact number',
                        //     prefixIcon: const Icon(
                        //       Icons.phone,
                        //       color: Colors.black,
                        //     ),
                        //   ),
                        //   validator: (val) => val!.isEmpty ? 'Enter a contact number' : null,
                        //   onChanged: (val) {
                        //     setState(() => contact = val);
                        //   },
                        // ),
                        // const SizedBox(height: 15.0,),

                        TextFormField(
                          decoration: textInputDecoration.copyWith(
                            hintText: 'Password',
                            prefixIcon: const Icon(
                              Icons.lock,
                              color: Colors.black,
                            ),
                          ),
                          obscureText: true,
                          validator: (val) => val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                          onChanged: (val) {
                            setState(() => password = val);
                          },
                        ),

                        const SizedBox(height: 20.0),

                        Row(
                          children: const <Widget>[
                            Expanded(
                              child: Divider(
                                color: Colors.white,
                                height: 8.0,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20.0),

                        RaisedButton(
                          child: const Padding(
                              padding: EdgeInsets.all(15.0),
                              child: Text('REGISTER')
                          ),
                          color: Colors.blueAccent[700],
                          textColor: Colors.white,
                          onPressed: () async {
                            if(_formKey.currentState!.validate()){
                              setState(() => loading = true);
                              await DatabaseService().insertUser(name,email,password);
                              // dynamic result = await _auth.registerWithEmailAndPassword(email, password);
                              // if(result == null) {
                              //   setState(() {
                              //     loading = false;
                              //     // error = 'Please supply a valid email';
                              //   });
                              //   return showDialog(
                              //     context: context,
                              //     builder: (context) {
                              //       return AlertDialog(
                              //         content: Text('ERROR! Please supply a valid email.'),
                              //       );
                              //     },
                              //   );
                              // } else {
                                setState(() {
                                  loading = false;
                                });

                                // DatabaseService().addUsersData(name, email, contact, address, city, userType);

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => LogIn()),
                                );
                              // }
                            }
                          }
                        ),

                        SizedBox(height: 15.0),

                        RaisedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => LogIn()),
                            );
                          },
                          child: const Padding(
                              padding: EdgeInsets.all(15.0),
                              child: Text('LOGIN')),
                          color: Colors.blueAccent,
                          textColor: Colors.white,
                        ),

                      ],
                    ),
                  ),
                ),
            ),
        ],
      ),

    );
  }
}