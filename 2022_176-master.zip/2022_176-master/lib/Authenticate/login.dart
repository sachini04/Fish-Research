import 'package:fish_app/Services/database.dart';
import 'package:flutter/material.dart';
import 'package:fish_app/Authenticate/register.dart';
import 'package:fish_app/main.dart';
import 'package:fish_app/home.dart';
import 'package:fish_app/shared/constants.dart';
import 'package:fish_app/shared/loading.dart';

class LogIn extends StatefulWidget {
  @override
  _LogInState createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  // final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();
  String error = '';
  bool loading = false;

  // text field state
  String email = '';
  String password = '';

  @override
  Widget build(BuildContext context) {
    return loading
        ? Loading()
        : Scaffold(
            backgroundColor: Colors.blue.shade100,
            body: Stack(
              children: <Widget>[
                Container(
                  decoration: new BoxDecoration(
                      image: new DecorationImage(
                          fit: BoxFit.fitWidth,
                          alignment: Alignment.bottomCenter,
                          image: AssetImage(
                              "assets/images/fish_back.png"))),
                ),
                Container(
                  decoration: new BoxDecoration(
                      image: new DecorationImage(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.topCenter,
                          image: AssetImage(
                              "assets/images/logo2.png"))),
                ),
                Center(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(30.0),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                         // SizedBox(height:250,child: Image.asset('assets/images/logo.png')),
                          Center(child: Text('Sign In',style: TextStyle(fontSize: 42),)),
                           SizedBox(
                            height: 25.0,
                          ),
                          TextFormField(
                            decoration: textInputDecoration.copyWith(
                              hintText: 'Email',
                              prefixIcon: Icon(
                                Icons.email_rounded,
                                color: Colors.black,
                              ),
                            ),
                            validator: (val) =>
                                val!.isEmpty ? 'Enter an email' : null,
                            onChanged: (val) {
                              setState(() => email = val);
                            },
                          ),
                          SizedBox(
                            height: 25.0,
                          ),
                          TextFormField(
                            decoration: textInputDecoration.copyWith(
                              hintText: 'Password',
                              prefixIcon: Icon(
                                Icons.lock,
                                color: Colors.black,
                              ),
                            ),
                            obscureText: true,
                            validator: (val) => val!.length < 6
                                ? 'Enter a password 6+ chars long'
                                : null,
                            onChanged: (val) {
                              setState(() => password = val);
                            },
                          ),
                          SizedBox(
                            height: 40.0,
                          ),
                          RaisedButton(
                              child: const Padding(
                                  padding: EdgeInsets.all(15.0),
                                  child: Text('LOGIN')),
                              color: Colors.blueAccent[700],
                              textColor: Colors.white,
                              onPressed: () async {
                                if (_formKey.currentState!.validate()) {
                                  setState(() => loading = true);
                                  String isAuth = await DatabaseService()
                                      .login(email, password);
                                  setState(() {
                                    loading = false;
                                  });
                                  if (isAuth != '') {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Home(isAuth)),
                                    );
                                  } else {
                                    return showDialog(
                                      context: context,
                                      builder: (context) {
                                        return const AlertDialog(
                                          content: Text(
                                              'Username or password is incorrect'),
                                        );
                                      },
                                    );
                                  }
                                }
                              }),
                          SizedBox(height: 20.0),
                          RaisedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Register()),
                              );
                            },
                            child: const Padding(
                                padding: EdgeInsets.all(15.0),
                                child: Text('REGISTER')),
                            color: Colors.blueAccent,
                            textColor: Colors.white,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
  }
}
