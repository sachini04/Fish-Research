import 'dart:io';

import 'package:fish_app/Authenticate/login.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:tflite/tflite.dart';

class ShrimpDisease extends StatefulWidget {
  @override
  ShrimpDiseaseState createState() {
    return ShrimpDiseaseState();
  }
}

// Define a corresponding State class.
// This class holds data related to the form.
class ShrimpDiseaseState extends State<ShrimpDisease> {
  final _formKey = GlobalKey<FormState>();

  String _name = '';
  String _remark = '';
  String _imageUrl = '';
  bool isPressed = false;

  //garbage and the level detection functions & variables
  late Future<File> imageFile;
  File? _image;
  String result = '';
  String confidenceLevel = '';
  ImagePicker? imagePicker;

  selectPhotoFromGallery() async {
    await Permission.photos.request();

    var permissionStatus = await Permission.photos.status;
    print(permissionStatus);

    if (permissionStatus.isGranted) {
      XFile? pickedFile =
          await imagePicker!.pickImage(source: ImageSource.gallery);

      setState(() {
        _image = File(pickedFile!.path);
        doUnkownDetection();
        //doImageClassification();
      });
    }
  }

  capturePhotoFromCamera() async {
    XFile? pickedFile =
        await imagePicker!.pickImage(source: ImageSource.camera);

    setState(() {
      _image = File(pickedFile!.path);
      doImageClassification();
    });
  }

  loadUnknownPhotoDetectModel() async {
    String? garbageOutput = await Tflite.loadModel(
      model: 'assets/unknown_shrimp/filterunknowshrimp.tflite',
      labels: 'assets/unknown_shrimp/uuknowshrimp.txt',
      numThreads: 1,
      isAsset: true,
      useGpuDelegate: false,
    );
    print(garbageOutput);
  }

  loadFishDetectModel() async {
    String? garbageOutput = await Tflite.loadModel(
      model: 'assets/shrimp_detection_model/shrimp_disease.tflite',
      labels: 'assets/shrimp_detection_model/labels_disease.txt',
      numThreads: 1,
      isAsset: true,
      useGpuDelegate: false,
    );
    print(garbageOutput);
  }

  doUnkownDetection() async {
    loadUnknownPhotoDetectModel();
    var unkown = await Tflite.runModelOnImage(
      path: _image!.path,
      imageMean: 0.0,
      imageStd: 255.0,
      numResults: 1,
      threshold: 0.1, //2 results per image
      asynch: true,
    );
    if (unkown!.first['label'] == 'unknown') {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return new AlertDialog(
              title: new Text("Image is not detected"),
              content: new Text("Selected image is not detected as a Shrimp."),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    doImageClassification();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    child: const Text(
                      "Continue",
                      style: TextStyle(color: Colors.cyan, fontSize: 17),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    selectPhotoFromGallery();
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    child: const Text(
                      "Select new image",
                      style: TextStyle(color: Colors.cyan, fontSize: 17),
                    ),
                  ),
                ),
              ],
            );
          });
    }else{
      doImageClassification();
    }
  }

  doImageClassification() async {
    loadFishDetectModel();
    var recognitions = await Tflite.runModelOnImage(
      path: _image!.path,
      imageMean: 0.0,
      imageStd: 255.0,
      numResults: 1,
      threshold: 0.1, //2 results per image
      asynch: true,
    );
    
    print(recognitions!.length.toString());
    // setState(() {
    //   result = '';
    // });

    recognitions.forEach((element) {
      setState(() {
        print('This is the elemenet' + element.toString());
        result = element['label'] + '\n\n';
        confidenceLevel = element['confidence'].toString();
      });
    });
  }

  @override
  void initState() {
    super.initState();
    imagePicker = ImagePicker();
    loadUnknownPhotoDetectModel();
    // print(_name);
  }

  @override
  void dispose() {
    super.dispose();
    Tflite.close();
  }

  @override
  Widget build(BuildContext context) {
    print(_name);
    return Scaffold(
      
        body: Stack(
          children: [
            Container(
          decoration: new BoxDecoration(
              image: new DecorationImage(
                  fit: BoxFit.cover,
                  alignment: Alignment.bottomCenter,
                  image: AssetImage("assets/images/shrimpback.png"))),
        ),
            SingleChildScrollView(
                child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                padding: const EdgeInsets.fromLTRB(30.0, 60.0, 30.0, 10.0),
                child: Row(
                  children: [
                    GestureDetector(
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                        child: Icon(Icons.arrow_back)),
                    const Expanded(
                        child: Center(
                      child: Text(
                        'Shrimp Disease Detection',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ))
                  ],
                ),
              ),
                 Padding(
                padding: const EdgeInsets.all(30.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30.0),
                  child: GestureDetector(
                    onTap: selectPhotoFromGallery,
                    onDoubleTap: capturePhotoFromCamera,
                    child: Container(
                      color: Colors.grey.shade500.withOpacity(0.5),
                      margin: const EdgeInsets.only(top: 1.0),
                      child: Stack(
                        children: <Widget>[
                          Center(
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(30.0),
                                child: _image != null
                                    ? Image.file(
                                        _image!,
                                        height: 400.0,
                                        width: 400.0,
                                        fit: BoxFit.scaleDown,
                                      )
                                    : SizedBox(
                                        height: 400.0,
                                        width: 400.0,
                                        child: Center(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(Icons.camera, size: 60),
                                              Text('Insert Image')
                                            ],
                                          ),
                                        ),
                                      )),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

                  // SizedBox(height: 10.0,),
// Displaying the detected result
              result == ''
                  ? Container()
                  : Center(
                      child: Container(
                        width: 350.0,
                        height: 200.0,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.grey.shade300.withOpacity(0.9),
                          // border: Border.all(
                          //   color: Colors.black,
                          //   width: 2.0,
                          // ),
                          borderRadius: BorderRadius.circular(10.0),
                          // gradient: const LinearGradient(
                          //     colors: [Colors.blue, Colors.white]),
                          // boxShadow: const [
                          //   BoxShadow(
                          //       color: Colors.black,
                          //       blurRadius: 2.0,
                          //       offset: Offset(2.0, 2.0))
                          // ],
                        ),
                        margin: const EdgeInsets.only(top: 10.0),
                        child: Text(
                          'The Result is :' +
                              '\n' +
                              '$result' +
                              '\n' +
                              'Confidence level is $confidenceLevel',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 25.0,
                            color: Colors.black,
                            fontFamily: 'RampartOne-Regular',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
              SizedBox(
                height: 10.0,
              ),
              result == ''
                  ? Container()
                  : Center(
                      child: SizedBox(
                        width: 300,
                        height: 55,
                        child: ElevatedButton(
                          style:
                              ElevatedButton.styleFrom(primary: Colors.blue[600]
                                  // foreground
                                  ),
                          onPressed: () async {},
                          child: const Text(
                            'More Info',
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 22.0),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            )),
          ],
        ));
  }
}
